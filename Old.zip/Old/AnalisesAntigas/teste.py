import json
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def load_results(file_path):
    """Carrega os resultados do JSON."""
    with open(file_path, 'r') as f:
        results = json.load(f)
    return results

def analyze_results(results):
    """Analisa os resultados carregados."""
    # Preparar uma tabela resumo
    summary = []
    for i, result in enumerate(results):
        alpha = result["alpha"]
        gamma = result["gamma"]
        epsilon_start = result["epsilon_start"]
        decay_step = result["decay_step"]
        avg_reward = result["average_reward"]
        std_dev_reward = result["std_dev_reward"]
        convergence_epoch = result["convergence_epoch"]
        stability_diffs = result["stability_diffs"]
        
        # Adicionar ao resumo
        summary.append({
            "Configuração": f"Setup {i+1}",
            "Alpha": alpha,
            "Gamma": gamma,
            "Epsilon Start": epsilon_start,
            "Decay Step": decay_step,
            "Recompensa Média": avg_reward,
            "Desvio Padrão": std_dev_reward,
            "Época de Convergência": convergence_epoch if convergence_epoch is not None else "Não Convergiu",
            "Estabilidade Final (Variação Média)": stability_diffs[-1] if stability_diffs else "N/A",
        })
        
        # Gráficos de convergência
        if stability_diffs:
            plt.figure(figsize=(10, 6))
            plt.plot(stability_diffs, label="Diferença Média da Política")
            plt.title(f"Convergência da Política - Configuração {i+1}")
            plt.xlabel("Época")
            plt.ylabel("Variação Média na Política")
            plt.grid()
            plt.legend()
            plt.show()
        
        # Recompensas por época
        rewards = result["rewards"]
        plt.figure(figsize=(10, 6))
        plt.plot(rewards, label="Recompensas")
        plt.title(f"Recompensas por Época - Configuração {i+1}")
        plt.xlabel("Época")
        plt.ylabel("Recompensas")
        plt.grid()
        plt.legend()
        plt.show()

    # Retorna o resumo como DataFrame
    return pd.DataFrame(summary)

def plot_comparison(summary_df):
    """Compara as configurações usando um gráfico de barras."""
    # Comparar épocas de convergência
    converged = summary_df[summary_df["Época de Convergência"] != "Não Convergiu"]
    if not converged.empty:
        plt.figure(figsize=(10, 6))
        plt.bar(converged["Configuração"], converged["Época de Convergência"], color='blue', alpha=0.7)
        plt.title("Época de Convergência por Configuração")
        plt.xlabel("Configuração")
        plt.ylabel("Época de Convergência")
        plt.grid(axis="y")
        plt.show()

    # Comparar recompensas médias
    plt.figure(figsize=(10, 6))
    plt.bar(summary_df["Configuração"], summary_df["Recompensa Média"], color='green', alpha=0.7)
    plt.title("Recompensa Média por Configuração")
    plt.xlabel("Configuração")
    plt.ylabel("Recompensa Média")
    plt.grid(axis="y")
    plt.show()

def main():
    file_path = "results.json"  # Caminho para o arquivo JSON
    results = load_results(file_path)
    summary_df = analyze_results(results)
    
    # Exibir a tabela resumo
    print(summary_df)
    
    # Comparar configurações
    plot_comparison(summary_df)

if __name__ == "__main__":
    main()
