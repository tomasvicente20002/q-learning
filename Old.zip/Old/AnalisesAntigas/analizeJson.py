# Código completo de análise em um único arquivo

import json
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Função para calcular a média e desvio-padrão usando janela deslizante
def calculate_rolling_stats(data, window_size=1000):
    rolling_mean = np.convolve(data, np.ones(window_size)/window_size, mode='valid')
    rolling_std = [np.std(data[i:i+window_size]) for i in range(len(data) - window_size + 1)]
    return rolling_mean, rolling_std

# Função para carregar e analisar o JSON
def analyze_qlearning_results(file_path, threshold=1e-3, required_stable_epochs=10, window_size=1000):
    # Carregar o arquivo JSON
    with open(file_path, 'r') as f:
        results = json.load(f)

    summary_data = []
    for i, result in enumerate(results):
        # Extrair parâmetros e resultados principais
        # Extrair parâmetros e resultados principais
        alpha = result["alpha"]
        gamma = result["gamma"]
        epsilon_start = result["epsilon_start"]
        decay_step = result["decay_step"]
        avg_reward = result["average_reward"]
        std_dev_reward = result["std_dev_reward"]
        convergence_epoch = result["convergence_epoch"]
        rewards = result["rewards"]
        stability_diffs = result.get("stability_diffs", [])
        
        summary_data.append({
            "Configuração": f"Setup {i+1}",
            "Alpha": alpha,
            "Gamma": gamma,
            "Epsilon Start": epsilon_start,
            "Decay Step": decay_step,
            "Recompensa Média": avg_reward,
            "Desvio Padrão": std_dev_reward,
            "Época de Convergência": convergence_epoch,
        })

        # Plotar recompensas por época (Gráfico de Dispersão)
        plt.figure(figsize=(10, 6))
        epochs = list(range(len(rewards)))  # Criar lista de épocas
        plt.scatter(epochs, rewards, alpha=0.6, label="Recompensas", s=10)  # Gráfico de dispersão
        plt.title(f"Recompensas por Época (Dispersão) - Configuração {i+1}")
        plt.xlabel("Época")
        plt.ylabel("Recompensas")
        plt.grid()
        plt.legend()
        plt.show()


        # Calcular e plotar estatísticas de janela deslizante
        rolling_mean, rolling_std = calculate_rolling_stats(rewards, window_size)
        plt.figure(figsize=(10, 6))
        plt.plot(rolling_mean, label="Média Móvel das Recompensas")
        plt.fill_between(range(len(rolling_mean)), 
                         rolling_mean - rolling_std, 
                         rolling_mean + rolling_std, 
                         color='b', alpha=0.2, label="Desvio Padrão")
        plt.title(f"Média e Desvio-Padrão das Recompensas - Configuração {i+1}")
        plt.xlabel("Época")
        plt.ylabel("Recompensas")
        plt.legend()
        plt.grid()
        plt.show()

        # Plotar variação na política, se disponível
        if stability_diffs:
            plt.figure(figsize=(10, 6))
            plt.plot(stability_diffs, label="Variação na Política")
            plt.axhline(y=threshold, color='r', linestyle='--', label="Threshold")
            plt.title(f"Variação na Política por Época - Configuração {i+1}")
            plt.xlabel("Época")
            plt.ylabel("Variação Média na Política")
            plt.grid()
            plt.legend()
            plt.show()

    # Criar resumo como DataFrame
    df_summary = pd.DataFrame(summary_data)
    print("Resumo das Configurações do Q-Learning:")
    print(df_summary)

    # Salvar resumo como CSV para análise posterior
    df_summary.to_csv("q_learning_summary.csv", index=False)
    print("Resumo salvo como 'q_learning_summary.csv'.")

    return df_summary

# Caminho do arquivo JSON (substituir pelo correto)
file_path = "results.json"

# Analisar resultados
df_summary = analyze_qlearning_results(file_path)
