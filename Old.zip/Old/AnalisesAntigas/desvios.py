import json
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Função para calcular a média e desvio-padrão usando janela deslizante
def calculate_rolling_stats(data, window_size=1000):
    rolling_mean = np.convolve(data, np.ones(window_size)/window_size, mode='valid')
    rolling_std = [np.std(data[i:i+window_size]) for i in range(len(data) - window_size + 1)]
    return rolling_mean, rolling_std

# Função para carregar e analisar o JSON
def analyze_qlearning_results(file_path, threshold=1e-3, required_stable_epochs=10, window_size=1000):
    # Carregar o arquivo JSON
    with open(file_path, 'r') as f:
        results = json.load(f)

    summary_data = []
    for i, result in enumerate(results):
        rewards = result["rewards"]
        # Calcular e plotar estatísticas de janela deslizante
        rolling_mean, rolling_std = calculate_rolling_stats(rewards, window_size)

        # Calcular a média dos desvios padrão a cada 50000 épocas
        std_averages = []
        indices = []
        for epoch in range(0, len(rolling_std), 50000):
            if epoch + 50000 < len(rolling_std):
                std_averages.append(np.mean(rolling_std[epoch:epoch+50000]))
                indices.append(epoch + 25000)  # Ponto médio para representação gráfica

        plt.figure(figsize=(10, 6))
        plt.plot(rolling_mean, label="Média Móvel das Recompensas")
        plt.fill_between(range(len(rolling_mean)), 
                         rolling_mean - rolling_std, 
                         rolling_mean + rolling_std, 
                         color='b', alpha=0.2, label="Desvio Padrão")
        # Adicionar pontos de média de desvios padrão
        plt.scatter(indices, std_averages, color='red', label='Média do Desvio Padrão a cada 50000 épocas', zorder=5)
        plt.title(f"Média e Desvio-Padrão das Recompensas - Configuração {i+1}")
        plt.xlabel("Época")
        plt.ylabel("Recompensas")
        plt.legend()
        plt.grid()
        plt.show()

    # Criar resumo como DataFrame
    df_summary = pd.DataFrame(summary_data)
    print("Resumo das Configurações do Q-Learning:")
    print(df_summary)

    # Salvar resumo como CSV para análise posterior
    df_summary.to_csv("q_learning_summary.csv", index=False)
    print("Resumo salvo como 'q_learning_summary.csv'.")

    return df_summary

# Caminho do arquivo JSON (substituir pelo correto)
file_path = "results.json"

# Analisar resultados
df_summary = analyze_qlearning_results(file_path)
