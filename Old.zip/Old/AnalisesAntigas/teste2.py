import json
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def load_results(file_path):
    """Carrega os resultados do JSON."""
    with open(file_path, 'r') as f:
        results = json.load(f)
    return results

def analyze_results(results):
    """Analisa os resultados carregados."""
    summary = []
    for i, result in enumerate(results):
        alpha = result["alpha"]
        gamma = result["gamma"]
        epsilon_start = result["epsilon_start"]
        decay_step = result["decay_step"]
        avg_reward = result["average_reward"]
        std_dev_reward = result["std_dev_reward"]
        convergence_epoch = result["convergence_epoch"]
        stability_diffs = result["stability_diffs"]

        # Adicionar ao resumo
        summary.append({
            "Configuração": f"Setup {i+1}",
            "Alpha": alpha,
            "Gamma": gamma,
            "Epsilon Start": epsilon_start,
            "Decay Step": decay_step,
            "Recompensa Média": avg_reward,
            "Desvio Padrão": std_dev_reward,
            "Época de Convergência": convergence_epoch if convergence_epoch is not None else "Não Convergiu",
        })

        # Gráfico de dispersão da convergência
        if stability_diffs:
            plt.figure(figsize=(10, 6))
            epochs = range(len(stability_diffs))
            plt.scatter(epochs, stability_diffs, s=10, alpha=0.7, label="Variação Média da Política")
            plt.title(f"Convergência da Política - Configuração {i+1}")
            plt.xlabel("Épocas")
            plt.ylabel("Variação Média na Política")
            plt.grid(True)
            plt.legend()
            plt.show()

    # Retorna o resumo como DataFrame
    return pd.DataFrame(summary)

def main():
    file_path = "results.json"  # Caminho para o arquivo JSON
    results = load_results(file_path)
    summary_df = analyze_results(results)

    # Exibir a tabela resumo
    print(summary_df)

if __name__ == "__main__":
    main()
