import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

def load_results(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def plot_rewards(rewards, labels):
    plt.figure(figsize=(12, 8))
    for reward, label in zip(rewards, labels):
        plt.plot(np.convolve(reward, np.ones(100)/100, mode='valid'), label=f'Alpha: {label["alpha"]}, Gamma: {label["gamma"]}, Decay: {label["decay_step"]}')
    plt.xlabel('Epochs')
    plt.ylabel('Smoothed Total Reward')
    plt.title('Smoothed Reward Trends by Setup')
    plt.legend()
    plt.grid(True)
    plt.show()

def plot_convergence(rewards, window_size=1000):
    plt.figure(figsize=(12, 6))
    for i, reward in enumerate(rewards):
        smoothed_rewards = np.convolve(reward, np.ones(window_size)/window_size, mode='valid')
        plt.plot(smoothed_rewards, label=f'Setup {i+1}')

    plt.title('Convergência das Recompensas ao Longo das Iterações')
    plt.xlabel('Iterações')
    plt.ylabel('Recompensa Média Suavizada')
    plt.legend()
    plt.grid(True)
    plt.show()

def plot_policy_heatmap(policies, labels):
    for i, policy in enumerate(policies):
        plt.figure(figsize=(8, 4))
        sns.heatmap(policy, annot=True, cmap="coolwarm", cbar=True)
        plt.title(f'Policy Heatmap - Setup {i+1}: Alpha {labels[i]["alpha"]}, Gamma {labels[i]["gamma"]}')
        plt.show()

def main():
    results = load_results('results.json')
    rewards = [result['rewards'] for result in results]
    policies = [np.array(result['final_policy']) for result in results]
    hyperparameters = [{'alpha': result['alpha'], 'gamma': result['gamma'], 'decay_step': result['decay_step']} for result in results]

    plot_rewards(rewards, hyperparameters)
    plot_convergence(rewards) # Example parameters for epsilon decay
    plot_policy_heatmap(policies, hyperparameters)

    for result, label in zip(results, hyperparameters):
        avg_reward = np.mean(result['rewards'])
        std_dev = np.std(result['rewards'])
        print(f"Setup - Alpha: {label['alpha']}, Gamma: {label['gamma']}, Decay: {label['decay_step']}")
        print(f"Average Reward: {avg_reward:.2f}, Std Dev: {std_dev:.2f}")

if __name__ == "__main__":
    main()
