import numpy as np
import matplotlib.pyplot as plt
import json
from gridworld import GridWorld
from qlearning import *
from datetime import datetime

TOP_EPOCH = 500000  # Número total de iterações
PRINT_EPOCH = 5000  # Intervalo para monitorizar resultados

def return_decayed_value(starting_value, global_step, decay_step):
    """Calcula o valor decaído."""
    decay_rate = 0.995  # Taxa de decaimento ajustável
    decayed_value = starting_value * np.power(decay_rate, (global_step / decay_step))
    return decayed_value

def update_state_action(state_action_matrix, visit_counter_matrix, observation, new_observation, 
                        action, reward, alpha, gamma):
    col = observation[1] + (observation[0] * 4)
    q = state_action_matrix[action, col]
    col_t1 = new_observation[1] + (new_observation[0] * 4)
    q_t1 = np.max(state_action_matrix[:, col_t1])
    # Atualizar alpha dinamicamente com base no número de visitas
    alpha_counted = alpha / (1.0 + visit_counter_matrix[action, col])
    state_action_matrix[action, col] = q + alpha_counted * (reward + gamma * q_t1 - q)
    return state_action_matrix


def serialize_results(results):
    serialized_results = []
    for result in results:
        serialized_result = {
            "alpha": result["alpha"],
            "gamma": result["gamma"],
            "epsilon_start": result["epsilon_start"],
            "decay_step": result["decay_step"],
            "rewards": result["rewards"],  # Recompensas totais por época
            "average_reward": np.mean(result["rewards"]),
            "std_dev_reward": np.std(result["rewards"]),
            "final_policy": result["final_policy"].tolist() if isinstance(result["final_policy"], np.ndarray) else result["final_policy"],
            "visit_counter_matrix": result["visit_counter_matrix"].tolist() if isinstance(result["visit_counter_matrix"], np.ndarray) else result["visit_counter_matrix"],  # Matriz de visitas
            "steps_per_epoch": result["steps_per_epoch"],  # Passos por época
            "convergence_epoch": result["convergence_epoch"],  # Época de convergência
        }
        serialized_results.append(serialized_result)
    return serialized_results



def main():
    env = GridWorld(3, 4)
    state_matrix = np.zeros((3, 4))
    state_matrix[0, 3] = 1
    state_matrix[1, 3] = 1
    state_matrix[1, 1] = -1
    reward_matrix = np.full((3, 4), -0.04)
    reward_matrix[0, 3] = 1
    reward_matrix[1, 3] = -1
    transition_matrix = np.array([[0.8, 0.1, 0.0, 0.1], 
                                   [0.1, 0.8, 0.1, 0.0], 
                                   [0.0, 0.1, 0.8, 0.1], 
                                   [0.1, 0.0, 0.1, 0.8]])
    policy_matrix = np.random.randint(low=0, high=4, size=(3, 4)).astype(np.float32)
    policy_matrix[1, 1] = np.nan
    policy_matrix[0, 3] = policy_matrix[1, 3] = -1
    env.setStateMatrix(state_matrix)
    env.setRewardMatrix(reward_matrix)
    env.setTransitionMatrix(transition_matrix)

    state_action_matrix = np.zeros((4, 12))
    visit_counter_matrix = np.zeros((4, 12))
    setups = [{"alpha": 0.01, "gamma": 0.99, "epsilon_start": 0.1, "decay_step": 50000}, 
              {"alpha": 0.1, "gamma": 0.9, "epsilon_start": 0.1, "decay_step": 50000}, 
              {"alpha": 0.001, "gamma": 0.8, "epsilon_start": 0.1, "decay_step": 100000}]
    results = []

    for setup in setups:
        alpha = setup["alpha"]
        gamma = setup["gamma"]
        epsilon_start = setup["epsilon_start"]
        decay_step = setup["decay_step"]

        state_action_matrix, policy_matrix, rewards, steps_per_epoch, convergence_epoch, stability_diffs = train_q_learning(
            env, alpha, gamma, epsilon_start, decay_step, policy_matrix, state_action_matrix, visit_counter_matrix)

        results.append({
            "alpha": alpha,
            "gamma": gamma,
            "epsilon_start": epsilon_start,
            "decay_step": decay_step,
            "rewards": rewards,
            "final_policy": policy_matrix.tolist(),
            "visit_counter_matrix": visit_counter_matrix.tolist(),
            "steps_per_epoch": steps_per_epoch,
            "convergence_epoch": convergence_epoch,
            "stability_diffs": stability_diffs,
        })

    with open('results.json', 'w') as f:
        json.dump(serialize_results(results), f)

def train_q_learning(env, alpha, gamma, epsilon_start, decay_step, policy_matrix, state_action_matrix, visit_counter_matrix, threshold=1e-3):
    rewards_per_epoch = []
    previous_policy_matrix = np.copy(policy_matrix)
    convergence_epoch = None
    steps_per_epoch = []
    stability_diffs = []  # Guardar variações médias da política
    stability_counter = 0
    required_stable_epochs = 10  # Número de épocas consecutivas para convergência

    for epoch in range(TOP_EPOCH):
        observation = env.reset(exploring_starts=True)
        epsilon = return_decayed_value(epsilon_start, epoch, decay_step)
        total_reward = 0
        steps = 0

        for _ in range(1000):
            action = return_epsilon_greedy_action(policy_matrix, observation, epsilon)
            new_observation, reward, done = env.step(action)
            total_reward += reward
            state_action_matrix = update_state_action(state_action_matrix, visit_counter_matrix, observation, new_observation, action, reward, alpha, gamma)
            policy_matrix = update_policy(policy_matrix, state_action_matrix, observation)
            visit_counter_matrix = update_visit_counter(visit_counter_matrix, observation, action)
            observation = new_observation
            steps += 1
            if done:
                break

        rewards_per_epoch.append(total_reward)
        steps_per_epoch.append(steps)

        # Calcular a variação média da política
        mean_diff = np.nanmean(np.abs(policy_matrix - previous_policy_matrix))
        stability_diffs.append(mean_diff)

        # Verificar convergência com base na estabilidade da política
        if mean_diff < threshold:
            stability_counter += 1
            if convergence_epoch is None and stability_counter >= required_stable_epochs:
                print(f"Política convergiu na época {epoch} após {stability_counter} épocas estáveis (variação média {mean_diff:.6f})")
                convergence_epoch = epoch
        else:
            stability_counter = 0

        previous_policy_matrix = np.copy(policy_matrix)

        if epoch % PRINT_EPOCH == 0:
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_message = (f"Data/Hora: {current_time}, Época: {epoch}, Epsilon: {epsilon:.6f}, "
                        f"Recompensa Média: {np.mean(rewards_per_epoch[-PRINT_EPOCH:]):.4f}, "
                        f"Variação Média na Política: {mean_diff:.6f}")

            print(log_message)

            with open("training_log.txt", "a") as log_file:
                log_file.write(log_message + "\n")

    return state_action_matrix, policy_matrix, rewards_per_epoch, steps_per_epoch, convergence_epoch, stability_diffs


if __name__ == "__main__":
    main()
