import json
import pandas as pd
import matplotlib.pyplot as plt

# Load the JSON file
def load_results(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

# Analyze rewards over iterations
def analyze_rewards(results):
    summaries = []
    for result in results:
        avg_reward = sum(result["rewards"]) / len(result["rewards"])
        summaries.append({
            "alpha": result["alpha"],
            "gamma": result["gamma"],
            "epsilon": result["epsilon"],
            "decay_step": result["decay_step"],
            "average_reward": avg_reward,
        })
    return pd.DataFrame(summaries)

# Plot rewards over iterations
def plot_rewards(results, max_plots=36):
    plt.figure(figsize=(10, 6))
    for i, result in enumerate(results[:max_plots]):
        plt.plot(result["rewards"], label=f"Run {i+1}: alpha={result['alpha']}, gamma={result['gamma']}")
    plt.title("Rewards Over Iterations")
    plt.xlabel("Iteration")
    plt.ylabel("Reward")
    plt.legend()
    plt.grid()
    plt.show()

# Main function to execute the analysis
def main():
    file_path = "results.json"  # Replace with your JSON file path
    results = load_results(file_path)
    
    # Analyze rewards
    summary_df = analyze_rewards(results)
    print("Summary of Results:")
    print(summary_df.head())
    
    # Plot rewards
    plot_rewards(results)

if __name__ == "__main__":
    main()