import numpy as np
import matplotlib.pyplot as plt
import json

def plot_all_trials_optimized(data, num_trials=3, sample_rate=100):
    """
    Plots all trials with optimized sampling for faster rendering.

    Args:
    - data: List of trial results.
    - num_trials: Number of trials to plot.
    - sample_rate: Interval for sampling rewards to reduce data points.
    """
    plt.figure(figsize=(12, 6))

    # Sample rewards for each trial
    trial_rewards = []
    for trial in range(num_trials):
        rewards = data[trial]["rewards"]
        sampled_rewards = rewards[::sample_rate]
        trial_rewards.append(sampled_rewards)
        plt.plot(sampled_rewards, alpha=0.5, label=f"Trial {trial + 1}")

    # Compute and plot the mean and standard deviation
    trial_rewards = np.array(trial_rewards)
    mean_rewards = np.mean(trial_rewards, axis=0)
    std_rewards = np.std(trial_rewards, axis=0)

    plt.plot(mean_rewards, color="black", linewidth=2, label="Mean Reward")
    plt.fill_between(
        range(len(mean_rewards)),
        mean_rewards - std_rewards,
        mean_rewards + std_rewards,
        color="gray",
        alpha=0.3,
        label="Standard Deviation",
    )

    # Finalize the plot
    plt.title("Convergence Analysis Across All Trials (Optimized)")
    plt.xlabel(f"Iteration (Sampled every {sample_rate})")
    plt.ylabel("Reward")
    plt.legend()
    plt.grid()
    plt.show()

# Example usage
file_path = "results.json"  # Replace with your file path
with open(file_path, 'r') as file:
    data = json.load(file)

plot_all_trials_optimized(data, num_trials=36, sample_rate=100)
input("as")