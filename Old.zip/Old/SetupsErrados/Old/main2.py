import numpy as np
from gridworld import GridWorld
from qlearning import update_state_action, update_policy, return_epsilon_greedy_action, update_visit_counter, return_decayed_value
import copy
import json

# Reduced number of epochs and adjusted print interval
TOP_EPOCH = 100000  # Reduced total number of epochs for initial testing
PRINT_EPOCH = 50000  # Adjusted interval to print results for better monitoring

def print_matrix(matrix, title="Matrix"):
    """Function to print matrix with formatted values."""
    print(f"\n{title}:")
    for row in matrix:
        formatted_row = ["{:+.2f}".format(val) if not np.isnan(val) else "NaN" for val in row]
        print("  ".join(formatted_row))

def print_policy_with_symbols(policy_matrix):
    """Displays the policy matrix with human-readable symbols."""
    symbols = {0: '^', 1: '>', 2: 'v', 3: '<', -1: '*', np.nan: '#'}
    print("\nPolicy Matrix with Symbols:")
    for row in policy_matrix:
        formatted_row = [symbols[val] if val in symbols else symbols[np.nan] for val in row]
        print("  ".join(formatted_row))

def serialize_results(results):
    serialized_results = []
    for result in results:
        serialized_result = {
            "alpha": result["alpha"],
            "gamma": result["gamma"],
            "epsilon": result["epsilon"],
            "decay_step": result["decay_step"],
            "rewards": result["rewards"],
            "final_policy": result["final_policy"].tolist()  # Converter matriz para lista
        }
        serialized_results.append(serialized_result)
    return serialized_results

def train_q_learning(env, alpha, gamma, epsilon_start, decay_step, policy_matrix, state_action_matrix, visit_counter_matrix, threshold=1e-3):
    """
    Train the Q-learning algorithm with dynamic convergence criteria.
    """
    rewards_per_epoch = []
    previous_policy_matrix = np.copy(policy_matrix)
    for epoch in range(TOP_EPOCH):
        observation = env.reset(exploring_starts=True)
        epsilon = return_decayed_value(epsilon_start, epoch, decay_step)
        total_reward = 0
        for _ in range(1000):  # Limit steps to avoid infinite loops
            action = return_epsilon_greedy_action(policy_matrix, observation, epsilon)
            new_observation, reward, done = env.step(action)
            total_reward += reward
            state_action_matrix = update_state_action(
                state_action_matrix, visit_counter_matrix, observation, new_observation, action, reward, alpha, gamma
            )
            policy_matrix = update_policy(policy_matrix, state_action_matrix, observation)
            visit_counter_matrix = update_visit_counter(visit_counter_matrix, observation, action)
            observation = new_observation
            if done:
                break

        rewards_per_epoch.append(total_reward)
        if np.array_equal(policy_matrix, previous_policy_matrix) and epoch > 1000:
            print(f"Policy converged at epoch {epoch}")
            break
        if epoch % PRINT_EPOCH == 0 or epoch == TOP_EPOCH - 1:
            print(f"\nEpoch {epoch}: Epsilon = {epsilon:.4f}, Total Reward = {total_reward:.2f}")
            print_matrix(state_action_matrix, title="State-Action Matrix after Epoch")
            print_policy_with_symbols(policy_matrix)
        previous_policy_matrix = np.copy(policy_matrix)

    return state_action_matrix, policy_matrix, rewards_per_epoch

def main():
    env = GridWorld(3, 4)
    state_matrix = np.zeros((3,4))
    state_matrix[0, 3] = 1; state_matrix[1, 3] = 1; state_matrix[1, 1] = -1
    reward_matrix = np.full((3, 4), -0.04)
    reward_matrix[0, 3] = 1; reward_matrix[1, 3] = -1
    transition_matrix = np.array([
        [0.8, 0.1, 0.0, 0.1],
        [0.1, 0.8, 0.1, 0.0],
        [0.0, 0.1, 0.8, 0.1],
        [0.1, 0.0, 0.1, 0.8]
    ])
    policy_matrix = np.full((3, 4), np.nan)
    policy_matrix[0, 3] = policy_matrix[1, 3] = -1
    policy_matrix[1, 1] = np.nan
    for i in range(3):
        for j in range(4):
            if np.isnan(policy_matrix[i, j]):
                continue
            policy_matrix[i, j] = np.random.randint(0, 4)
    env.setStateMatrix(state_matrix)
    env.setRewardMatrix(reward_matrix)
    env.setTransitionMatrix(transition_matrix)
    state_action_matrix = np.zeros((4, 12))
    visit_counter_matrix = np.zeros((4, 12))

    setups = [
        {"alpha": 0.01, "gamma": 0.99, "epsilon_start": 0.1, "decay_step": 100000},
        {"alpha": 0.1, "gamma": 0.9, "epsilon_start": 0.1, "decay_step": 50000},
        {"alpha": 0.001, "gamma": 0.8, "epsilon_start": 0.1, "decay_step": 200000}
    ]
    
    results = []

    for setup in setups:
        alpha = setup["alpha"]
        gamma = setup["gamma"]
        epsilon_start = setup["epsilon_start"]
        decay_step = setup["decay_step"]
        
        print(f"Training with alpha: {alpha}, gamma: {gamma}, decay step: {decay_step}")
        state_action_matrix, policy_matrix, rewards_per_epoch = train_q_learning(copy.deepcopy(env), alpha, gamma, epsilon_start, decay_step,
                                copy.deepcopy(policy_matrix), copy.deepcopy(state_action_matrix),
                                copy.deepcopy(visit_counter_matrix))
        
        results.append({
            "alpha": alpha,
            "gamma": gamma,
            "epsilon": epsilon_start,
            "decay_step": decay_step,
            "rewards": rewards_per_epoch,
            "final_policy": policy_matrix
        })
        
        # Salvar resultados em arquivo JSON
    with open('results.json', 'w') as f:
        json.dump(serialize_results(results), f)

if __name__ == "__main__":
    main()
