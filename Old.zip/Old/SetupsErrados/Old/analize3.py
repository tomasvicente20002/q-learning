import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import json

# Função para calcular métricas de recompensas por intervalo
def analyze_rewards_by_interval(rewards, interval=100000):
    intervals = range(0, len(rewards), interval)
    avg_rewards = [np.mean(rewards[i:i+interval]) for i in intervals]
    std_rewards = [np.std(rewards[i:i+interval]) for i in intervals]
    return intervals, avg_rewards, std_rewards

# Função para calcular estabilidade e convergência
def analyze_stability(rewards, last_iterations=10000):
    last_rewards = rewards[-last_iterations:]
    avg_last_rewards = np.mean(last_rewards)
    std_last_rewards = np.std(last_rewards)
    return avg_last_rewards, std_last_rewards

# Função para plotar recompensas por intervalo
def plot_rewards_intervals(rewards, interval=100000):
    intervals, avg_rewards, std_rewards = analyze_rewards_by_interval(rewards, interval)
    plt.figure(figsize=(10, 6))
    plt.errorbar(intervals, avg_rewards, yerr=std_rewards, fmt='-o', label="Recompensa Média por Intervalo")
    plt.title("Recompensas Médias por Intervalos")
    plt.xlabel("Iteração")
    plt.ylabel("Recompensa Média")
    plt.grid()
    plt.legend()
    plt.show()

# Função para comparar diferentes configurações
def compare_hyperparameters(data):
    metrics = []
    for experiment in data:
        avg_reward = np.mean(experiment["rewards"])
        std_reward = np.std(experiment["rewards"])
        avg_last_rewards, std_last_rewards = analyze_stability(experiment["rewards"])
        metrics.append({
            "alpha": experiment["alpha"],
            "gamma": experiment["gamma"],
            "epsilon": experiment["epsilon"],
            "decay_step": experiment["decay_step"],
            "avg_reward": avg_reward,
            "std_reward": std_reward,
            "avg_last_rewards": avg_last_rewards,
            "std_last_rewards": std_last_rewards
        })
    return pd.DataFrame(metrics)

# Função principal
def main():
    # Substitua pelo caminho do arquivo JSON com os dados
    file_path = "results.json"  # Substitua pelo seu caminho
    with open(file_path, 'r') as file:
        data = json.load(file)
    
    # Comparar configurações de hiperparâmetros
    metrics_df = compare_hyperparameters(data)
    print("Métricas Calculadas:")
    print(metrics_df)

    # Plotar recompensas para uma configuração específica
    rewards = data[0]["rewards"]  # Alterar o índice para analisar diferentes configurações
    plot_rewards_intervals(rewards)

    # Salvar métricas em CSV para análise posterior
    metrics_df.to_csv("q_learning_metrics.csv", index=False)
    print("Métricas salvas em 'q_learning_metrics.csv'")

if __name__ == "__main__":
    main()
