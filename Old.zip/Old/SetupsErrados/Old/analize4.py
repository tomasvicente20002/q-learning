import numpy as np
import matplotlib.pyplot as plt
import json

def analyze_convergence(data, num_trials=3, last_iterations=1000):
    # Aggregate rewards over trials
    trial_rewards = []
    for trial in range(num_trials):
        trial_rewards.append(data[trial]["rewards"])
    
    # Convert to NumPy array for easier manipulation
    trial_rewards = np.array(trial_rewards)
    
    # Calculate mean and standard deviation across trials
    mean_rewards = np.mean(trial_rewards, axis=0)
    std_rewards = np.std(trial_rewards, axis=0)
    
    # Convergence detection (mean rewards stabilize in last_iterations)
    avg_last_rewards = np.mean(mean_rewards[-last_iterations:])
    std_last_rewards = np.std(mean_rewards[-last_iterations:])
    
    print(f"Average Reward in Last {last_iterations} Iterations: {avg_last_rewards}")
    print(f"Standard Deviation in Last {last_iterations} Iterations: {std_last_rewards}")
    
    # Plot reward curves for each trial and mean rewards
    plt.figure(figsize=(10, 6))
    for trial in range(num_trials):
        plt.plot(trial_rewards[trial], alpha=0.5, label=f"Trial {trial+1}")
    plt.plot(mean_rewards, color='black', label="Mean Reward", linewidth=2)
    plt.fill_between(range(len(mean_rewards)), mean_rewards - std_rewards, mean_rewards + std_rewards, alpha=0.2, color='gray', label="Std Deviation")
    plt.title("Q-Learning Convergence Analysis")
    plt.xlabel("Iteration")
    plt.ylabel("Reward")
    plt.legend()
    plt.grid()
    plt.show()
    
    # Return metrics
    return avg_last_rewards, std_last_rewards

# Example usage
def main():
    file_path = "results.json"  # Replace with your JSON file path
    with open(file_path, 'r') as file:
        data = json.load(file)
    
    avg_reward, std_reward = analyze_convergence(data, num_trials=3, last_iterations=1000)
    print("Conclusion:")
    print(f"Q-Learning Algorithm converges to an average reward of {avg_reward:.2f} with a standard deviation of {std_reward:.2f} in the last iterations.")

if __name__ == "__main__":
    main()


