import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import json
import pandas as pd

def plot_smoothed_rewards(data, num_trials=36, window=1000):
    plt.figure(figsize=(12, 6))
    for trial in range(num_trials):
        rewards = data[trial]["rewards"]
        smoothed = np.convolve(rewards, np.ones(window) / window, mode="valid")
        plt.plot(smoothed, alpha=0.8, label=f"Trial {trial + 1} (Smoothed)")
    plt.title("Smoothed Reward Curve")
    plt.xlabel("Iteration")
    plt.ylabel("Smoothed Reward")
    plt.legend()
    plt.grid()
    plt.show()

def plot_boxplot_rewards(data, num_trials=36, interval=10000):
    rewards_per_interval = []
    for trial in range(num_trials):
        rewards = data[trial]["rewards"]
        for i in range(0, len(rewards), interval):
            rewards_per_interval.append({
                "Trial": f"Trial {trial + 1}",
                "Interval": f"{i}-{i+interval}",
                "Reward": np.mean(rewards[i:i+interval])
            })
    rewards_df = pd.DataFrame(rewards_per_interval)
    plt.figure(figsize=(12, 6))
    sns.boxplot(x="Interval", y="Reward", hue="Trial", data=rewards_df)
    plt.xticks(rotation=45)
    plt.title("Boxplot of Rewards Across Intervals")
    plt.xlabel("Iteration Interval")
    plt.ylabel("Reward")
    plt.legend()
    plt.grid()
    plt.show()

def plot_heatmap_rewards(data, num_trials=36, window=1000):
    heatmap_data = []
    for trial in range(num_trials):
        rewards = data[trial]["rewards"]
        smoothed = np.convolve(rewards, np.ones(window) / window, mode="valid")
        heatmap_data.append(smoothed)
    heatmap_data = np.array(heatmap_data)
    plt.figure(figsize=(12, 6))
    sns.heatmap(heatmap_data, cmap="coolwarm", cbar=True, annot=False)
    plt.title("Heatmap of Smoothed Rewards Across Trials")
    plt.xlabel("Iteration (Smoothed)")
    plt.ylabel("Trial")
    plt.show()

# Example usage
def main():
    file_path = "results.json"  # Replace with your JSON file path
    with open(file_path, 'r') as file:
        data = json.load(file)

    # Plot alternatives
    plot_smoothed_rewards(data)
    plot_boxplot_rewards(data)
    plot_heatmap_rewards(data)

if __name__ == "__main__":
    main()
