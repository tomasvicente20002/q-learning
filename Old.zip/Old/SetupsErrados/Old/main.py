import numpy as np
import matplotlib.pyplot as plt
from gridworld import GridWorld
from qlearning import *
import copy
import json

# Definir iterações
TOP_EPOCH = 100000  # Reduced total number of epochs for initial testing
PRINT_EPOCH = 50000  # Adjusted interval to print results for better monitoring

def print_matrix(matrix, title="Matrix"):
    print(f"\n{title}:")
    for row in matrix:
        formatted_row = ["{:+.2f}".format(val) if not np.isnan(val) else "NaN" for val in row]
        print("  ".join(formatted_row))

def print_policy_with_symbols(policy_matrix):
    '''Exibe a matriz de política com símbolos legíveis'''
    symbols = {0: '^', 1: '>', 2: 'v', 3: '<', -1: '*', np.nan: '#'}
    print("\nPolicy Matrix with Symbols:")
    for row in policy_matrix:
        formatted_row = [symbols[val] if not np.isnan(val) else symbols[np.nan] for val in row]
        print("  ".join(formatted_row))
        

def train_q_learning(env, alpha, gamma, epsilon_start, decay_step, policy_matrix, state_action_matrix, visit_counter_matrix, threshold=1e-4):
    """
    Treina o algoritmo Q-Learning com critérios de convergência.
    """
    rewards_per_epoch = []
    previous_policy_matrix = np.copy(policy_matrix)
    converged = False

    for epoch in range(TOP_EPOCH):
        # Reiniciar o ambiente e pegar a primeira observação
        observation = env.reset(exploring_starts=True)
        epsilon = return_decayed_value(epsilon_start, epoch, decay_step)
        total_reward = 0

        for _ in range(1000):
            # Selecionar ação usando epsilon-greedy
            action = return_epsilon_greedy_action(policy_matrix, observation, epsilon)

            # Executar a ação no ambiente
            new_observation, reward, done = env.step(action)
            total_reward += reward

            # Atualizar matriz de Q-values
            state_action_matrix = update_state_action(
                state_action_matrix, visit_counter_matrix, observation, new_observation, 
                action, reward, alpha, gamma
            )

            # Atualizar matriz de política
            policy_matrix = update_policy(policy_matrix, state_action_matrix, observation)

            # Atualizar contador de visitas
            visit_counter_matrix = update_visit_counter(visit_counter_matrix, observation, action)

            # Atualizar a observação
            observation = new_observation

            # Encerrar se o estado terminal for alcançado
            if done:
                break

        rewards_per_epoch.append(total_reward)

        # Verificar convergência da política
        if epoch % 100 == 0:  # Verificar a cada 100 iterações
            if np.all(np.abs(policy_matrix - previous_policy_matrix) < threshold):
                print(f"Policy converged at epoch {epoch}")
                converged = True
                break  # Parar se convergir
            previous_policy_matrix = np.copy(policy_matrix)

        # Exibir progresso a cada PRINT_EPOCH
        if epoch != 0 and epoch % PRINT_EPOCH == 0:
            print(f"\nEpoch {epoch}: Epsilon = {epsilon:.4f}, Total Reward = {total_reward:.2f}")
            print_matrix(state_action_matrix, title="State-Action Matrix after Epoch")
            print_policy_with_symbols(policy_matrix)

    if converged:
        avg_reward = np.mean(rewards_per_epoch[-1000:])
        std_reward = np.std(rewards_per_epoch[-1000:])
        print(f"Converged with Avg Reward: {avg_reward:.4f}, Std Dev: {std_reward:.4f}")
        with open('convert.txt', 'a') as f:
            f.write(f"Alpha: {alpha} Gamma:{gamma} Epsilon:{epsilon} Decay Step:{decay_step}")
            f.write(f"Converged with Avg Reward: {avg_reward:.4f}, Std Dev: {std_reward:.4f}")

    return state_action_matrix, policy_matrix, rewards_per_epoch

        

# Converter matrizes numpy para listas antes de salvar
def serialize_results(results):
    serialized_results = []
    for result in results:
        serialized_result = {
            "alpha": result["alpha"],
            "gamma": result["gamma"],
            "epsilon": result["epsilon"],
            "decay_step": result["decay_step"],
            "rewards": result["rewards"],
            "final_policy": result["final_policy"].tolist()  # Converter matriz para lista
        }
        serialized_results.append(serialized_result)
    return serialized_results


def main():
    # Criação do ambiente GridWorld
    env = GridWorld(3, 4)

    # Definir a matriz de estados (0: transitável, -1: obstáculo, 1: terminal)
    state_matrix = np.zeros((3, 4))
    state_matrix[0, 3] = 1  # Estado terminal positivo
    state_matrix[1, 3] = 1  # Estado terminal positivo
    state_matrix[1, 1] = -1  # Obstáculo
    print_matrix(state_matrix, title="State Matrix")

    # Definir a matriz de recompensas
    reward_matrix = np.full((3, 4), -0.04)  # Penalidade por movimento
    reward_matrix[0, 3] = 1  # Recompensa positiva
    reward_matrix[1, 3] = -1  # Recompensa negativa
    print_matrix(reward_matrix, title="Reward Matrix")

    # Definir a matriz de transições (probabilidades para ações não determinísticas)
    transition_matrix = np.array([[0.8, 0.1, 0.0, 0.1],
                                   [0.1, 0.8, 0.1, 0.0],
                                   [0.0, 0.1, 0.8, 0.1],
                                   [0.1, 0.0, 0.1, 0.8]])

    # Inicializar a matriz de política aleatória
    policy_matrix = np.random.randint(low=0, high=4, size=(3, 4)).astype(np.float32)
    policy_matrix[1, 1] = np.NaN  # NaN para o obstáculo
    policy_matrix[0, 3] = policy_matrix[1, 3] = -1  # Estados terminais não têm ações
    print_matrix(policy_matrix, title="Policy Matrix")
    print_policy_with_symbols(policy_matrix)

    # Configurar o ambiente
    env.setStateMatrix(state_matrix)
    env.setRewardMatrix(reward_matrix)
    env.setTransitionMatrix(transition_matrix)

    # Inicializar matrizes para aprendizado
    state_action_matrix = np.zeros((4, 12))  # Q-values
    visit_counter_matrix = np.zeros((4, 12))

    setups = [
        {"alpha": 0.01, "gamma": 0.99, "epsilon_start": 0.1, "decay_step": 100000},
        {"alpha": 0.1, "gamma": 0.9, "epsilon_start": 0.1, "decay_step": 50000},
        {"alpha": 0.001, "gamma": 0.8, "epsilon_start": 0.1, "decay_step": 200000}
    ]
    
    results = []

    for setup in setups:
        alpha = setup["alpha"]
        gamma = setup["gamma"]
        epsilon = setup["epsilon_start"]
        decay_step = setup["decay_step"]

        state_action_matrix, policy_matrix, rewards_per_epoch =  train_q_learning(copy.deepcopy(env),
                            alpha, gamma,
                            epsilon,
                            decay_step, 
                            copy.deepcopy(policy_matrix),
                            copy.deepcopy(state_action_matrix),
                            copy.deepcopy(visit_counter_matrix))
        results.append({
            "alpha": alpha,
            "gamma": gamma,
            "epsilon": epsilon,
            "decay_step": decay_step,
            "rewards": rewards_per_epoch,
            "final_policy": policy_matrix
        })

    # Salvar resultados em arquivo JSON
    with open('results.json', 'w') as f:
        json.dump(serialize_results(results), f)

if __name__ == "__main__":
    main()