import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import json

# Função para calcular métricas
def calculate_metrics(results):
    metrics = []
    for result in results:
        rewards = np.array(result["rewards"])
        cumulative_rewards = np.cumsum(rewards)  # Recompensa cumulativa
        avg_reward = np.mean(rewards)  # Recompensa média
        std_reward = np.std(rewards)  # Desvio padrão
        stability_reward = np.std(rewards[-1000:])  # Estabilidade nas últimas 1000 iterações
        convergence_step = next(
            (i for i in range(100, len(rewards)) if np.mean(rewards[i-100:i]) >= 0.95 * avg_reward),
            len(rewards)
        )  # Estimar convergência
        metrics.append({
            "alpha": result["alpha"],
            "gamma": result["gamma"],
            "epsilon": result["epsilon"],
            "decay_step": result["decay_step"],
            "avg_reward": avg_reward,
            "std_reward": std_reward,
            "stability_reward": stability_reward,
            "cumulative_reward": cumulative_rewards[-1],
            "convergence_step": convergence_step,
        })
    return pd.DataFrame(metrics)

# Função para plotar recompensas cumulativas
def plot_cumulative_rewards(results, max_plots=36):
    plt.figure(figsize=(10, 6))
    for i, result in enumerate(results[:max_plots]):
        cumulative_rewards = np.cumsum(result["rewards"])
        plt.plot(cumulative_rewards, label=f"Run {i+1}: alpha={result['alpha']}, gamma={result['gamma']}")
    plt.title("Cumulative Rewards Over Iterations")
    plt.xlabel("Iteration")
    plt.ylabel("Cumulative Reward")
    plt.legend()
    plt.grid()
    plt.show()

# Função para plotar distribuição de recompensas
def plot_reward_distribution(results, max_plots=36):
    plt.figure(figsize=(10, 6))
    for i, result in enumerate(results[:max_plots]):
        plt.hist(result["rewards"], bins=50, alpha=0.5, label=f"Run {i+1}: alpha={result['alpha']}, gamma={result['gamma']}")
    plt.title("Reward Distribution")
    plt.xlabel("Reward")
    plt.ylabel("Frequency")
    plt.legend()
    plt.grid()
    plt.show()

# Função para heatmap de métricas
# Função para heatmap de métricas
def plot_heatmap(metrics_df, metric="avg_reward"):
    pivot_table = metrics_df.pivot_table(values=metric, index="alpha", columns="gamma")
    plt.figure(figsize=(8, 6))
    plt.title(f"Heatmap of {metric}")
    plt.xlabel("Gamma")
    plt.ylabel("Alpha")
    sns.heatmap(pivot_table, annot=True, fmt=".2f", cmap="coolwarm")
    plt.show()


# Função principal
def main():
    file_path = "results.json"  # Substitua pelo caminho do seu arquivo JSON
    with open(file_path, 'r') as file:
        results = json.load(file)
    
    # Calcular métricas
    metrics_df = calculate_metrics(results)
    print("Métricas Calculadas:")
    print(metrics_df.head())

    # Salvar métricas em CSV
    metrics_df.to_csv("q_learning_metrics.csv", index=False)
    print("Métricas salvas em 'q_learning_metrics.csv'")

    # Plotar recompensas cumulativas
    plot_cumulative_rewards(results)

    # Plotar distribuição de recompensas
    #plot_reward_distribution(results)

    # Heatmap de recompensa média
    plot_heatmap(metrics_df, metric="avg_reward")

if __name__ == "__main__":
    main()